<?php
  include '../connect/dbconfig.php';

  
  //echo $_POST['book_job'];
/*  if (isset($_POST['book'])) {

   $dom = new DOMDocument("1.0");
    $node = $dom->createElement("markers");
    $parnode = $dom->appendChild($node);
    # code...
    $job = $_POST['book_job'];
    $query = "SELECT * FROM  profile_jobseekers, duong WHERE profile_jobseekers.fk_job = $job
                                                AND profile_jobseekers.fk_duong = duong.MaD";
    $result = mysqli_query($conn, $query);
    if (!$result) {
      die('Invalid query: ' . mysqli_error());
    }

    header("Content-type: text/xml");

    while ($row = mysqli_fetch_assoc($result)) {
        $node = $dom->createElement("marker");
        $newnode = $parnode->appendChild($node);
        $newnode->setAttribute("id",$row['Ma_profile']);
      }
     echo $dom->saveXML();
  }*/
 ?>
