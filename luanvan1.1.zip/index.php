<!DOCTYPE html>
<html lang="en">
  <head>

    <title>Website rao vặt nhanh|hoàn toàn miễn phí</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- css bootstrap -->

    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="css/register.css">
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="css/forget_pass.css">
    <link rel="stylesheet" href="css/post.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js" ></script>
  <script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
   <script src="https://use.fontawesome.com/4a3e77fddd.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>


    <!-- Jequery -->
  </head>
  <body id="mypage">
    <!-- php code direction -->
    <?php
    /*-- database --*/
    include("connect/dbconfig.php");
    /*-- layout home website --*/
    include("direction/d_website.php");
    /*-- layout content --*/
      #include("direction/content.php");
    /*-- layout footer --*/
    include("direction/footer.php");
    ?>
    <!-- JS -->
    <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.js"></script>
  </body>
</html>
