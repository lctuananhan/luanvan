<style media="screen">
  .circle {
    display: block;
    margin: 0 auto;
    margin-top: 100px;
    border-radius: 50%;
    height: 150px;
    width: 150px;


  }

  .text {
    margin-top: 100px;
  }
  .text a:link {
    text-decoration: none;
  }
  #map {
    width:100%; height:400px; margin-top: 50px;
  }
  .book {
    margin-top: 100px;
  }
  .book label {
    font-weight: 400;
    color: #2E2E2E !important;
  }

</style>
<?php
include 'layout/w_junior/header.php';
include 'layout/function/profile.php';
include 'handle/handle_profile_show.php';
include 'handle/handle_avatar.php';
//include 'ajax/ajax_book.php';
?>
<div class="container">
  <div class="row">
    <div class="col-sm-2">

        <?php if ( isset($_SESSION['avatar_name'])): ?>

          <?php echo "<img src='$image_src' class='image-circle circle'  >"; ?>
          <?php else: ?>
          <img src="image/user_default.jpg" class="image-circle circle"  alt="Cinque Terre">
        <?php endif; ?>



    </div>
    <div class="col-sm-4 text">
      <?php if (isset($_SESSION['show_name']) && isset($_SESSION['show_phone']) && isset($_SESSION['show_address'])): ?>
          <p>Họ và tên:<?php echo "<span style='font-weight:bold;'> ".$show_name."</span>"; ?> </p>
          <p>Số điện thoại:<?php echo "<span> ".$show_phone."</span>"; ?> </p>
          <p>Email:<?php echo "<span> ".$_SESSION['email']."</span>"; ?> </p>
          <p>Địa chỉ:<?php echo "<span> ".$show_address."</span>"; ?></p>
          <a href="" data-toggle="modal" data-target="#profile">Cập nhật</a><span>&nbsp;</span>
          <a href="">Quản lý hồ sơ</a>
        <?php else: ?>
          <p>Họ và tên:<span style="font-style: italic;"> Chưa cập nhật...</span> </p>
          <p>Số điện thoại:<span style="font-style: italic;"> Chưa cập nhật...</span> </p>
          <p>Email: <?php echo "<span> ".$_SESSION['email']."</span>"; ?> </p>
          <p>Địa chỉ:<span style="font-style: italic;"> Chưa cập nhật...</span></p>
          <a href="" data-toggle="modal" data-target="#profile">Cập nhật</a>
      <?php endif; ?>
    </div>
    <div class="col-sm-6 text-center book">
      <form class="form-horizontal" id="book_form" method="post">
      <!--  <div class="form-group">
          <label class="control-label col-sm-2" for="">Địa chỉ</label>
          <div class="col-sm-8">
            <input type="hidden" class="form-control" name="" id="value" value="" >
          </div>
        </div> -->

        <div class="form-group">
          <label class="control-label col-sm-2" for="">Việc làm</label>
          <div class="col-sm-8">
            <select class="form-control book_job" id="book_job" name="book_job">
              <option value="">--- Việc làm ---</option>
              <?php include 'handle/handle_job.php'; ?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <span class="col-sm-2"></span>
          <div class="col-sm-8">
            <button type="submit" class="btn btn-success btn-block" id="book" name="book"> Book</button>
          </div>
        </div>


      </form>


      <div id="data" >
      
      </div>



    </div>
  </div>
  <div class="row">
      <div id="map" style=""></div>
  </div>
</div>
<script>
function myMap() {
  map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 10.839778, lng: 106.638368},
        zoom: 10
      });
      infoWindow = new google.maps.InfoWindow;
      // Try HTML5 geolocation.
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
          var pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
        /*  infoWindow.setPosition(pos);
          infoWindow.setContent('Location found.');
          infoWindow.open(map);
          map.setCenter(pos);*/


         var marker = new google.maps.Marker({
            position:pos,
            animation:google.maps.Animation.BOUNCE
          });
          marker.setMap(map);
          return pos;
        }, function() {
          handleLocationError(true, infoWindow, map.getCenter());
        });


      } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, infoWindow, map.getCenter());
      }

    }

    function handleLocationError(browserHasGeolocation, infoWindow, pos) {
      infoWindow.setPosition(pos);
      infoWindow.setContent(browserHasGeolocation ?
                            'Error: The Geolocation service failed.' :
                            'Error: Your browser doesn\'t support geolocation.');
      infoWindow.open(map);
    }
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDuXzQdrNytPjoYtu2vqOZSQL962QTyV4Q&callback=myMap"></script>
