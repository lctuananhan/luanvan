<?php #session_start(); ?>
<?php
  include("w_junior/header.php");
  include("w_junior/h_content.php");
?>
