<?php
  include '../connect/dbconfig.php';



  if (isset($_POST['sendmail'])) {
  /*  require 'PHPMailerAutoload.php';
    require 'class.phpmailer.php';
    require 'class.smtp.php';
    $mail = new PHPMailer;
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'tuananh93.hcmut@gmail.com';                 // SMTP username
    $mail->Password = 'tuananh@1993';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;

    $mail->From = 'tuananh93.hcmut@gmail.com';
    $mail->FromName = 'BConline';*/






    # code...
    #$headers = "From:tuananh93.hcmut@gmail.com";
    $sql = "SELECT * FROM matching, post WHERE matching.fk_job = post.fk_Job
                                          AND matching.fk_tt = post.fk_TT
                                          AND matching.fk_qh = post.fk_QH";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($result)) {
      $email = $row['email'];
      $post_name = $row['post_Name'];

    #  $mail->addAddress($email);
      #$mail->isHTML(true);                                  // Set email format to HTML
      #$mail->Subject = $post_name;
    #  $mail->Body    = $row['post_Direc'];
      #$mail->AltBody = '';
      echo $email;
    }

    #mail("lctuananhan@gmail.com", "Testing", "test", "From: tuananh93.hcmut@gmail.com");
    #echo "email sent...";
  /*  if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        echo "<script>alert('Gửi mail thành công'); history.back();</script>";
    }*/
  }
?>
